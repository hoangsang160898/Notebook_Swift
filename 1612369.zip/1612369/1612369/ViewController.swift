//
//  ViewController.swift
//  1612369
//
//  Created by sv on 11/23/18.
//  Copyright © 2018 sv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    //MARK : Outlet
    
    @IBOutlet weak var imgView1: UIImageView!
    @IBOutlet weak var lblTitle1: UILabel!
    
    @IBOutlet weak var imgView2: UIImageView!
    @IBOutlet weak var lblTitle2: UILabel!
    
    @IBOutlet weak var imgView3: UIImageView!
    @IBOutlet weak var lblTitle3: UILabel!
    
    @IBOutlet weak var imgView4: UIImageView!
    @IBOutlet weak var lblTitle4: UILabel!
    
    @IBOutlet weak var imgView5: UIImageView!
    @IBOutlet weak var llblTitle5: UILabel!
    
    @IBOutlet weak var imgView6: UIImageView!
    @IBOutlet weak var lblTitle6: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createMain()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    func createMain(){
        
        self.imgView1.image = UIImage(named: "note1.jpg")
        self.lblTitle1.text = "Note"
        
        self.imgView2.image = UIImage(named: "title2.jpg")
        self.lblTitle2.text = "Emotion"
        
        self.imgView2.image = UIImage(named: "titl3.jpg")
        self.lblTitle2.text = "Work"
        self.imgView2.image = UIImage(named: "title4.jpg")
        self.lblTitle2.text = "Discover"
        self.imgView2.image = UIImage(named: "title5.jpg")
        self.lblTitle2.text = "Feeling"
        self.imgView2.image = UIImage(named: "title2.jpg")
        self.lblTitle2.text = "Something"
    }
}

